"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const functions_1 = require("@azure/functions");
const storage_blob_1 = require("@azure/storage-blob");
const httpTrigger = (req, context) => __awaiter(void 0, void 0, void 0, function* () {
    context.log('Psychologist application submission function processed a request.');
    try {
        // Parse the request body
        const applicationData = (yield req.json());
        if (!applicationData) {
            return {
                status: 400,
                jsonBody: { error: 'No application data provided' },
            };
        }
        // Generate application ID
        const applicationId = `APP-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
        applicationData.applicationId = applicationId;
        applicationData.submittedAt = new Date();
        // Validate required fields
        const validationErrors = validateApplication(applicationData);
        if (validationErrors.length > 0) {
            return {
                status: 400,
                jsonBody: { error: 'Validation failed', details: validationErrors },
            };
        }
        // Handle file uploads to Azure Blob Storage
        const fileUrls = yield handleFileUploads(context, applicationData, applicationId);
        // Store application data (in a real implementation, this would go to a database)
        // For now, we'll just log it and return success
        context.log(`Application submitted successfully: ${applicationId}`);
        context.log(`Files uploaded: ${Object.keys(fileUrls).length}`);
        // Send notification email (placeholder - would integrate with SendGrid)
        yield sendNotificationEmail(applicationData);
        // Return success response
        return {
            status: 200,
            jsonBody: {
                success: true,
                applicationId: applicationId,
                message: "Application submitted successfully. We'll review your application and contact you within 5-7 business days.",
                fileUrls: fileUrls,
            },
        };
    }
    catch (error) {
        context.error('Error processing application submission:', error);
        return {
            status: 500,
            jsonBody: { error: 'Internal server error' },
        };
    }
});
function validateApplication(data) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s;
    const errors = [];
    // Required personal information
    if (!((_a = data.fullName) === null || _a === void 0 ? void 0 : _a.trim()))
        errors.push('Full name is required');
    if (!((_b = data.email) === null || _b === void 0 ? void 0 : _b.trim()))
        errors.push('Email is required');
    if (!((_c = data.phone) === null || _c === void 0 ? void 0 : _c.trim()))
        errors.push('Phone number is required');
    // AHPRA validation
    if (!((_d = data.ahpraNumber) === null || _d === void 0 ? void 0 : _d.trim()))
        errors.push('AHPRA number is required');
    if (!data.ahpraExpiry)
        errors.push('AHPRA expiry date is required');
    if (!((_e = data.qualifications) === null || _e === void 0 ? void 0 : _e.trim()))
        errors.push('Qualifications are required');
    if (!((_f = data.institution) === null || _f === void 0 ? void 0 : _f.trim()))
        errors.push('Institution is required');
    if (!data.graduationYear)
        errors.push('Graduation year is required');
    // Qualification gate - must meet at least one criterion
    const meetsCriteria = data.isRegisteredClinicalPsychologist ||
        (data.yearsRegisteredWithAHPRA && data.yearsRegisteredWithAHPRA >= 8) ||
        data.hasPhD;
    if (!meetsCriteria) {
        errors.push('Must be a registered Clinical Psychologist, have 8+ years AHPRA registration, or hold a PhD in Psychology');
    }
    // Professional experience
    if (!data.yearsExperience && data.yearsExperience !== 0)
        errors.push('Years of experience is required');
    if (!((_g = data.specialties) === null || _g === void 0 ? void 0 : _g.length))
        errors.push('At least one specialty is required');
    if (!((_h = data.motivation) === null || _h === void 0 ? void 0 : _h.trim()))
        errors.push('Motivation statement is required');
    // Work preferences
    if (!data.currentWeeklyClientHours && data.currentWeeklyClientHours !== 0)
        errors.push('Current weekly client hours is required');
    if (!data.lookingToReplaceOrSupplement)
        errors.push('Work preference selection is required');
    if (!((_j = data.currentEmploymentStatus) === null || _j === void 0 ? void 0 : _j.trim()))
        errors.push('Current employment status is required');
    if (!data.availableStartDate)
        errors.push('Available start date is required');
    // Telehealth setup
    if (!((_k = data.state) === null || _k === void 0 ? void 0 : _k.trim()))
        errors.push('State is required');
    if (!((_l = data.timezone) === null || _l === void 0 ? void 0 : _l.trim()))
        errors.push('Timezone is required');
    // Insurance & compliance
    if (data.hasInsurance === undefined)
        errors.push('Insurance status is required');
    if (data.hasWorkingWithChildrenCheck === undefined)
        errors.push('Working with Children Check status is required');
    // References
    if (!((_m = data.reference1Name) === null || _m === void 0 ? void 0 : _m.trim()))
        errors.push('First reference name is required');
    if (!((_o = data.reference1Email) === null || _o === void 0 ? void 0 : _o.trim()))
        errors.push('First reference email is required');
    if (!((_p = data.reference1Relationship) === null || _p === void 0 ? void 0 : _p.trim()))
        errors.push('First reference relationship is required');
    if (!((_q = data.reference2Name) === null || _q === void 0 ? void 0 : _q.trim()))
        errors.push('Second reference name is required');
    if (!((_r = data.reference2Email) === null || _r === void 0 ? void 0 : _r.trim()))
        errors.push('Second reference email is required');
    if (!((_s = data.reference2Relationship) === null || _s === void 0 ? void 0 : _s.trim()))
        errors.push('Second reference relationship is required');
    // Consents
    if (!data.privacyConsent)
        errors.push('Privacy consent is required');
    if (!data.backgroundCheckConsent)
        errors.push('Background check consent is required');
    return errors;
}
function handleFileUploads(context, data, applicationId) {
    return __awaiter(this, void 0, void 0, function* () {
        const fileUrls = {};
        const connectionString = process.env.AZURE_STORAGE_CONNECTION_STRING;
        if (!connectionString) {
            context.warn('Azure Storage connection string not configured');
            return fileUrls;
        }
        try {
            const blobServiceClient = storage_blob_1.BlobServiceClient.fromConnectionString(connectionString);
            const containerName = 'applications';
            const containerClient = blobServiceClient.getContainerClient(containerName);
            // Ensure container exists
            yield containerClient.createIfNotExists({ access: 'blob' });
            const files = [
                { key: 'cvFile', file: data.cvFile, name: 'cv' },
                {
                    key: 'ahpraCertificateFile',
                    file: data.ahpraCertificateFile,
                    name: 'ahpra-certificate',
                },
                {
                    key: 'insuranceCertificateFile',
                    file: data.insuranceCertificateFile,
                    name: 'insurance-certificate',
                },
            ];
            for (const fileInfo of files) {
                if (fileInfo.file) {
                    const blobName = `${applicationId}/${fileInfo.name}-${Date.now()}`;
                    const blockBlobClient = containerClient.getBlockBlobClient(blobName);
                    // In a real implementation, you'd upload the actual file content
                    // For now, we'll just create a placeholder
                    const fileContent = `Placeholder for ${fileInfo.name} file`;
                    yield blockBlobClient.upload(fileContent, fileContent.length);
                    fileUrls[fileInfo.key] = blockBlobClient.url;
                    context.log(`Uploaded ${fileInfo.key} to ${blobName}`);
                }
            }
        }
        catch (error) {
            context.error('Error uploading files:', error);
            // Don't fail the application submission if file upload fails
        }
        return fileUrls;
    });
}
function sendNotificationEmail(data) {
    return __awaiter(this, void 0, void 0, function* () {
        // Placeholder for email notification
        // In a real implementation, this would use SendGrid or similar service
        console.log(`Sending notification email for application ${data.applicationId} to admin`);
        // Example email content:
        // To: admin@life-psychology.com.au
        // Subject: New Psychologist Application Received
        // Body: Application details...
    });
}
functions_1.app.http('submitApplication', {
    methods: ['POST'],
    authLevel: 'anonymous',
    route: 'applications/submit',
    handler: httpTrigger,
});
//# sourceMappingURL=index.js.map