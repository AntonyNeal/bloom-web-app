"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = void 0;
const functions_1 = require("@azure/functions");
Object.defineProperty(exports, "app", { enumerable: true, get: function () { return functions_1.app; } });
// Import and register all functions
require("./applications/submit/index");
require("./applications/get-sas-token/index");
//# sourceMappingURL=index.js.map