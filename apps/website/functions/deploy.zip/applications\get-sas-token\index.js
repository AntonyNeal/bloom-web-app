"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const functions_1 = require("@azure/functions");
const storage_blob_1 = require("@azure/storage-blob");
const httpTrigger = (req, context) => __awaiter(void 0, void 0, void 0, function* () {
    var _a, _b;
    context.log('Get SAS token function processed a request.');
    try {
        // Get query parameters
        const url = new URL(req.url);
        const fileName = url.searchParams.get('fileName');
        const fileType = url.searchParams.get('fileType');
        if (!fileName) {
            return {
                status: 400,
                jsonBody: { error: 'fileName query parameter is required' },
            };
        }
        // Validate file type
        const allowedTypes = [
            'application/pdf',
            'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'image/jpeg',
            'image/png',
        ];
        if (fileType && !allowedTypes.includes(fileType)) {
            return {
                status: 400,
                jsonBody: { error: 'File type not allowed' },
            };
        }
        // Get Azure Storage connection string
        const connectionString = process.env.AZURE_STORAGE_CONNECTION_STRING;
        if (!connectionString) {
            return {
                status: 500,
                jsonBody: { error: 'Storage configuration not found' },
            };
        }
        // Generate unique blob name
        const timestamp = Date.now();
        const randomId = Math.random().toString(36).substr(2, 9);
        const blobName = `temp/${timestamp}-${randomId}-${fileName}`;
        // Create BlobServiceClient
        const blobServiceClient = storage_blob_1.BlobServiceClient.fromConnectionString(connectionString);
        const containerName = 'applications';
        const containerClient = blobServiceClient.getContainerClient(containerName);
        // Ensure container exists (without public access)
        yield containerClient.createIfNotExists();
        const blobClient = containerClient.getBlobClient(blobName);
        // Generate SAS token with write permissions
        const startsOn = new Date();
        const expiresOn = new Date(startsOn);
        expiresOn.setMinutes(startsOn.getMinutes() + 15); // 15 minutes expiry
        const sasOptions = {
            containerName: containerName,
            blobName: blobName,
            permissions: storage_blob_1.BlobSASPermissions.parse('w'), // write permission
            startsOn: startsOn,
            expiresOn: expiresOn,
            protocol: storage_blob_1.SASProtocol.Https,
        };
        // Extract account name and key from connection string for SAS generation
        const connStrParts = connectionString.split(';');
        const accountName = (_a = connStrParts
            .find((p) => p.startsWith('AccountName='))) === null || _a === void 0 ? void 0 : _a.split('=')[1];
        const accountKey = (_b = connStrParts
            .find((p) => p.startsWith('AccountKey='))) === null || _b === void 0 ? void 0 : _b.split('=')[1];
        if (!accountName || !accountKey) {
            return {
                status: 500,
                jsonBody: { error: 'Invalid storage connection string' },
            };
        }
        const { StorageSharedKeyCredential } = yield Promise.resolve().then(() => __importStar(require('@azure/storage-blob')));
        const sharedKeyCredential = new StorageSharedKeyCredential(accountName, accountKey);
        const sasToken = (0, storage_blob_1.generateBlobSASQueryParameters)(sasOptions, sharedKeyCredential).toString();
        // Return the SAS URL
        const sasUrl = `${blobClient.url}?${sasToken}`;
        return {
            status: 200,
            jsonBody: {
                sasUrl: sasUrl,
                blobName: blobName,
                expiresAt: expiresOn.toISOString(),
            },
        };
    }
    catch (error) {
        context.error('Error generating SAS token:', error);
        return {
            status: 500,
            jsonBody: { error: 'Failed to generate SAS token' },
        };
    }
});
functions_1.app.http('getSasToken', {
    methods: ['GET'],
    authLevel: 'anonymous',
    route: 'applications/get-sas-token',
    handler: httpTrigger,
});
//# sourceMappingURL=index.js.map