"use strict";
// Test setup file for Azure Functions
// Mocks and global test configuration
Object.defineProperty(exports, "__esModule", { value: true });
exports.mockRequest = exports.mockContext = void 0;
// Mock Azure Functions context
exports.mockContext = {
    invocationId: 'test-invocation-id',
    executionContext: {
        invocationId: 'test-invocation-id',
        functionName: 'test-function',
        functionDirectory: '/test',
    },
    bindings: {},
    bindingData: {},
    log: Object.assign((...args) => {
        console.log('[MOCK LOG]', ...args);
    }, {
        error: jest.fn(),
        warn: jest.fn(),
        info: jest.fn(),
        verbose: jest.fn(),
    }),
    done: jest.fn(),
    res: {},
};
// Mock Azure Functions request
const mockRequest = (overrides = {}) => (Object.assign({ method: 'GET', url: 'http://localhost:7071/api/test', headers: {}, query: {}, params: {}, body: undefined, rawBody: undefined }, overrides));
exports.mockRequest = mockRequest;
// Reset all mocks before each test
beforeEach(() => {
    jest.clearAllMocks();
});
// Global test environment setup
const originalConsole = global.console;
global.console = Object.assign(Object.assign({}, originalConsole), { 
    // Suppress console.log in tests unless explicitly needed
    log: jest.fn(), warn: jest.fn(), error: jest.fn() });
//# sourceMappingURL=setup.js.map