"use strict";
/**
 * Database Version Control System - TypeScript Types
 *
 * Shared interfaces for the migration service, CLI tools, and Azure Functions.
 *
 * @author LPA Development Team
 * @date 2025-11-27
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map